
# EXERCISE 5
# Write one or more lines of code that will calculate and print the 
# sum of all odd numbers in the list number_list defined above.

print ("Exercise 5")
print ("**********************************")

