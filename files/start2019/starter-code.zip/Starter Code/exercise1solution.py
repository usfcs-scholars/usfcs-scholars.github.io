print ("Exercise 1")
print ("**********************************")
print ("Here is a house!")
print ("   +   ")
print ("  + +  ")
print (" +   + ")
print ("+-----+")
print ("| .-. |")
print ("| | | |")
print ("+-+-+-+")

# complete the code to produce the following output
#      +
#     + +
#    +   +
#   +-----+
#   | .-. |
#   | | | |
#   +-+-+-+ 

print ("**********************************\n\n")

print ("Exercise 2")
print ("**********************************")

product = 1
# Uncomment and complete the code to multiply the first five positive integers starting at 1.
#for i in range(# YOUR CODE HERE#):
for i in range(1, 6):
    #YOUR CODE HERE
    product = product * i
print("The product of the first five positive integers starting at 1 is %d." % product) # should print 120

print ("**********************************\n\n")


print ("Exercise 3")
print ("**********************************")

x = 5
y = 10

# Assign values to the variables below to calculate the difference, product, and average of the values in x and y.
difference = x-y
product = x*y
average = (x+y)/2.0

# Uncomment and complete the statement below so that it will print the difference between x and y.
print ("The difference between x and y is %d" % difference)
print ("The product of x and y is %d" % product)
print ("The average of x and y is %f" % average)
# Write a statement to print the product of x and y.
# Write a statement to print the average of x and y. Make sure this prints 7.5!


print ("**********************************\n\n")

print ("Exercise 4")
print ("**********************************")

# Given a list of numbers print all even numbers in the list
number_list = [1, 2, 3, 4, 5, 16, 18, 23]

for number in number_list:
    # Write a condition that will test whether the value in number is even
    # If the condition is true, print the value in number
    if number % 2 == 0:
        print (number)
print ("**********************************\n\n")

print ("Exercise 5")
print ("**********************************")

# Write a block of code that will calculate and print the sum of all odd numbers 
# in the list number_list defined above.

