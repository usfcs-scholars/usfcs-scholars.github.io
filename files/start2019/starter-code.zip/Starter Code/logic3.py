# We need to use some functionality from the math library.
import math

# Ask the user to tell us how many guests will attend the BBQ and how many hot dogs each guest will be alloted.
number_guests = float(input("How many guests will attend your BBQ? "))
number_dogs_per_guest = float(input("How hungry are they :)? How many hot dogs per guest? "))

# Define some variables to make our calculations easier.
dogs_per_pack = 10
buns_per_pack = 8

total_dogs = number_guests * number_dogs_per_guest
total_packs_of_dogs = math.ceil(total_dogs/dogs_per_pack)
leftover_dogs = (total_packs_of_dogs*dogs_per_pack)-total_dogs
print("Total dogs required = %d" % total_dogs)
print("Total packages of dogs required = %d" % total_packs_of_dogs)
print("Left over dogs = %d" % leftover_dogs)


total_buns = number_guests * number_dogs_per_guest
#total_packs_of_buns = math.ceil(total_buns/buns_per_pack)
total_packs_of_buns = math.ceil(total_buns/dogs_per_pack)
leftover_buns = (total_packs_of_buns*buns_per_pack)-total_buns
print("Total buns required = %d" % total_buns)
print("Total packages of buns required = %d" % total_packs_of_buns)
print("Left over buns = %d" % leftover_buns)

