# EXERCISE 2
# Replace the # YOUR CODE HERE markers below with 
# code that will calculate the product of the
# first five positive integers starting at 1.

print ("Exercise 2")
print ("**********************************")

product = 1
for i in range( # YOUR CODE HERE ):
    # YOUR CODE HERE
    
# The output of the following statement should be as follows:
# The product of the first five positive integers starting at 1 is 120.
print("The product of the first five positive integers starting at 1 is %d." % product) 

print ("**********************************\n\n")
