name = input("What is your name? ")
color = input("What is your favorite color? ")

print("Hello %s, you like the color %s!" % (color, name))

# How did you determine there was an error?
# What strategies did you use for finding the error?
