from PIL import Image

# need a worksheet for stepping through downloading the code?
# review the skelton code for copying the image
# give them flipVertical as mystery method and have them guess what it will do then run it
# have them implement flipHorizontal
# have them implement makeGreyscale
# have them work through the rotate algorithm then present then try to implement

def main():
    # Change the path in Line 6 to the path of the image you want to use as input 
    inputImage = Image.open('usfca_logo.png')
    imageWidth, imageHeight = inputImage.size
    blur(inputImage, imageWidth, imageHeight)


def blur(inputImage, imageWidth, imageHeight):
    copyImageOutput = Image.new('RGB', (imageWidth, imageHeight), 'white')
    
    #does not handle the edges


    for i in range(1, imageWidth-1):
        for j in range(1, imageHeight-1):
            pixelColors = inputImage.getpixel((i, j))

            redTotal = 0
            greenTotal = 0
            blueTotal = 0

            innerRuns = 0
            for k in range(i-1, i+2):
                for l in range(j-1, j+2):
                    neighborPixelColors = inputImage.getpixel((k, l))
                    redTotal += neighborPixelColors[0]
                    greenTotal += neighborPixelColors[1]
                    blueTotal += neighborPixelColors[2]
                    innerRuns += 1
            #print(innerRuns)

            redAvg = int(redTotal/9)
            greenAvg = int(greenTotal/9)
            blueAvg = int(blueTotal/9)
            
            copyImageOutput.putpixel((i, j), (redAvg, greenAvg, blueAvg))

    copyImageOutput.save('out.png')



#############################################
def swapCorners(inputImage, imageWidth, imageHeight):
    copyImageOutput = Image.new('RGB', (imageWidth, imageHeight), 'white')
    
    halfWidth = imageWidth/2
    halfHeight = imageHeight/2

    for i in range(halfWidth):
        for j in range(halfHeight):
            pixelColors = inputImage.getpixel((i, j))
            newI = i+halfWidth
            newJ = j+halfHeight
            copyImageOutput.putpixel((newI, newJ), pixelColors)

    for i in range(halfWidth, imageWidth):
        for j in range(halfHeight):
            pixelColors = inputImage.getpixel((i, j))
            newI = i-halfWidth
            newJ = j+halfHeight
            copyImageOutput.putpixel((newI, newJ), pixelColors)

    for i in range(halfWidth, imageWidth):
        for j in range(halfHeight, imageHeight):
            pixelColors = inputImage.getpixel((i, j))
            newI = i-halfWidth
            newJ = j-halfHeight
            copyImageOutput.putpixel((newI, newJ), pixelColors)

    for i in range(halfWidth):
        for j in range(halfHeight, imageHeight):
            pixelColors = inputImage.getpixel((i, j))
            newI = i+halfWidth
            newJ = j-halfHeight
            copyImageOutput.putpixel((newI, newJ), pixelColors)



def rotate(inputImage, imageWidth, imageHeight):
    copyImageOutput = Image.new('RGB', (imageHeight, imageWidth), 'white')
    
    for i in range(imageWidth):
        for j in range(imageHeight):
            pixelColors = inputImage.getpixel((i, j))
            newj = imageWidth-i-1
            copyImageOutput.putpixel((j, newj), pixelColors)

    copyImageOutput.save('out.png')

def makeGrayscale(inputImage, imageWidth, imageHeight):
    copyImageOutput = Image.new('RGB', (imageWidth, imageHeight), 'white')
    
    for i in range(imageWidth):
        for j in range(imageHeight):
            pixelColors = inputImage.getpixel((i, j))
            newValue = int(pixelColors[0]*.3) + int(pixelColors[1]*.59) + int(pixelColors[2]*.11)
            newPixel = (newValue, newValue, newValue)
            copyImageOutput.putpixel((i, j), newPixel)

    copyImageOutput.save('out.png')

def flipVertical(inputImage, imageWidth, imageHeight):
    copyImageOutput = Image.new('RGB', (imageWidth, imageHeight), 'white')
    
    for i in range(imageWidth):
        for j in range(imageHeight):
            pixelColors = inputImage.getpixel((i, j))
            copyImageOutput.putpixel((i, (imageHeight-1-j)), pixelColors)

    copyImageOutput.save('out.png')

def flipHorizontal(inputImage, imageWidth, imageHeight):
    copyImageOutput = Image.new('RGB', (imageWidth, imageHeight), 'white')

    for i in range(imageWidth):
        for j in range(imageHeight):
            pixelColors = inputImage.getpixel((i, j))
            copyImageOutput.putpixel(((imageWidth-1-i), j), pixelColors)

    copyImageOutput.save('out.png')

# Creates a copy of an image given the image variable, its width, and height
def copyImage(inputImage, imageWidth, imageHeight):
    copyImageOutput = Image.new('RGB', (imageWidth, imageHeight), 'white')

    redPixel = (255, 0, 0)

    for i in range(imageWidth):
        for j in range(imageHeight):
            pixelColors = inputImage.getpixel((i, j))
            copyImageOutput.putpixel((i, j), pixelColors)

    copyImageOutput.save('out.png')

def removeRed(inputImage, imageWidth, imageHeight):
    copyImageOutput = Image.new('RGB', (imageWidth, imageHeight), 'white')

    redPixel = (255, 0, 0)
    whitePixel = (0, 0, 0)

    for i in range(imageWidth):
        for j in range(imageHeight):
            
            pixelColors = inputImage.getpixel((i, j))
            if pixelColors[0] == 255: #and pixelColors[1] == 0 and pixelColors[2] == 0:
#                newPixel = (0 , pixelColors[1], pixelColors[2])
                newPixel = (0, 0, 0)
                copyImageOutput.putpixel((i, j), newPixel)
#            elif pixelColors[0] != 0:
#                newPixel = (0 , 0, 0)
#                copyImageOutput.putpixel((i, j), newPixel)
            else:
               copyImageOutput.putpixel((i, j), pixelColors)

    copyImageOutput.save('out.png')

main()
