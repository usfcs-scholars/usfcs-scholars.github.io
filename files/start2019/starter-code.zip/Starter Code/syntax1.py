x = 5

if x > 10:
print("x is large")
else:
print("x is small")
