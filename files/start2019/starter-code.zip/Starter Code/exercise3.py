# EXERCISE 3
# Replace the # YOUR CODE HERE markers below with
# code that will calculate the correct values for
# difference, product, and average. Complete the
# print statements to output correctly formatted  
# results.

print ("Exercise 3")
print ("**********************************")

x = 5
y = 10

# Assign values to the variables below to calculate the difference, product, and average of the values in x and y.
difference = # YOUR CODE HERE
product = # YOUR CODE HERE
average = # YOUR CODE HERE

# Uncomment and complete the statement below so that it will print the difference between x and y.
print ("The difference between x and y is %d" # YOUR CODE HERE)
# Write a statement to print the product of x and y.
# Write a statement to print the average of x and y. Make sure this prints 7.5!

