# get input from user and convert to the appropriate type (integer or floating point)
number_items = int(input("How many apples would you like to buy? "))
cost_per_item = float(input("How much is each apple? "))
amount_paid = float(input("How much will you pay? "))

change = amount_paid - (number_items * cost_per_item)
print("Your change will be %.2f.\n\n" % amount_paid) 
