
# EXERCISE 1
# Complete the code below so that the output looks as follows:
#      +
#     + +
#    +   +
#   +-----+
#   | .-. |
#   | | | |
#   +-+-+-+ 


print ("Exercise 1")
print ("**********************************")
print ("Here is a house!")
print ("   +   ")
print ("  + +  ")
print (" +   + ")
# YOUR CODE HERE

