print ("Where is the syntax error?')
print ("What are some of the ways you might identify the problem?")

