
# EXERCISE 4
# Complete the code below to print all even 
# numbers in number_list.

print ("Exercise 4")
print ("**********************************")

number_list = [1, 2, 3, 4, 5, 16, 18, 23]

for number in number_list:
    # Write a condition that will test whether the value in number is even
    # If the condition is true, print the value in number
    # YOUR CODE HERE
print ("**********************************\n\n")


