print("")

try:
	print("roses are red")
	print("violets are blue")

	import nvuji 

except SyntaxError as e:
	print(e.args[0])
	print("in line {}".format(e.args[1][1]))

print("")
# source: https://www.reddit.com/r/Jokes/comments/c6x0ei/programming_joke/
