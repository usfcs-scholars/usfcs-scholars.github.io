
echo ""
echo "rain rain go away"
echo "come again another day"
echo ""

