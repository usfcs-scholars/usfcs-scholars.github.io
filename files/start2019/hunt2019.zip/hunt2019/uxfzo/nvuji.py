
print("")

"""
This poem, commonly used as a love poem, is
inspired by a nursery rhyme from 1874. It has
a Roud Folk Song Index number of 19798.

There are many different versions of this poem.

The first phrase, "roses are red," is also
the name of a band, novel, film, and various
songs and albums.

Even the second phrase, "violets are blue,"
may refer to a novel, film, song, or play.

Source: https://en.wikipedia.org/wiki/Roses_Are_Red
"""
def poem():
    print("roses are red")
	print("violets are blue")
	print("sugar is sweet")
	print("and so are you")

poem()
print("")

